package Ingresso;
import java.util.*;

public class Vip extends Ingresso {

    public Vip(Date dataVenda, double precoBase){   
        super(dataVenda, precoBase);
    }
    
    @Override
    public double calculaReceita() {
        return preco * 2;
    }

    @Override
    public String exibeExtrato() {
        String s = "Ingresso VIP - " + dataVenda + " - R$" + calculaReceita();
        return s;
    }

}
