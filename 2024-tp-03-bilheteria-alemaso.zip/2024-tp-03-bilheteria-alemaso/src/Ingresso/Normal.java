package Ingresso;

import java.util.*;

public class Normal extends Ingresso {

    public Normal(Date dataVenda, double precoBase){   
        super(dataVenda, precoBase);
    }
    
    @Override
    public double calculaReceita() {
        return preco;
    }

    @Override
    public String exibeExtrato() {
        String s = "Ingresso Normal - " + dataVenda + " - R$" + calculaReceita();
        return s;
    }

}
