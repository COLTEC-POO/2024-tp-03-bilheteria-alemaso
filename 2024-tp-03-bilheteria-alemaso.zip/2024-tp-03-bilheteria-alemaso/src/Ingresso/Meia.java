package Ingresso;

import java.util.*;;

public class Meia extends Ingresso {

    public Meia(Date dataVenda, double precoBase){   
        super(dataVenda, precoBase);
    }
    
    @Override
    public double calculaReceita() {
        return preco/2;
    }

    @Override
    public String exibeExtrato() {
        String s = "Ingresso Meia - " + dataVenda + " - R$" + calculaReceita();
        return s;
    }

}
