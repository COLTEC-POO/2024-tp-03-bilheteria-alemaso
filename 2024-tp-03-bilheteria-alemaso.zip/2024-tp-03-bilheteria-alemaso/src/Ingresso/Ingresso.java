package Ingresso;

import java.util.*;

import Receita.Receita;

public abstract class Ingresso implements Receita{
    protected Date dataVenda;
    protected double preco;
    
    public Ingresso(Date data, double preco){
        this.dataVenda = data;
        this.preco = preco;
    }
}
