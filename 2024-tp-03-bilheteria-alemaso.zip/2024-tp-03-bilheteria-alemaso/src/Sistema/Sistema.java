package Sistema;


import java.util.*;
import Evento.Evento;


public class Sistema {
    public static ArrayList<Evento> eventos = new ArrayList<>();
    public static double receitaTotal;
    public static void main(String[] args) {
        GUI g = new GUI();
    }

    public static double calculaReceitaTotal(){
        double total = 0;
        for (Evento e : eventos)
            total += e.calculaReceita();
        return total;
    }

}