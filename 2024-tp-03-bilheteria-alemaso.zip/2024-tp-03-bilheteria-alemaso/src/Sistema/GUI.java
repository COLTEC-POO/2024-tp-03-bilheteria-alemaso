package Sistema;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.formdev.flatlaf.*;
import Evento.*;
import Ingresso.*;
import java.util.*;

public class GUI {
    private JFrame frame;
    private JPanel mainPanel;
    private JLabel label;
    private JButton btn;
    private JComboBox<String> comboBox;

    public GUI() {
        FlatDarculaLaf.setup(); //theme
        createGUI();
    }

    private void createGUI() {
        frame = new JFrame("TP-03");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setBounds(500, 300, 1000, 600);
    
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout()); // Layout
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
        label = new JLabel("<html><h2>Bem vindo à Bilheteria da paixão e força alemã! </nobr></h2></html>");
        label.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(label, BorderLayout.NORTH); // Adicionar o label ao topo do painel
    
        ImageIcon img = new ImageIcon("img/img.png");
        img = new ImageIcon(img.getImage().getScaledInstance(300, 175,  java.awt.Image.SCALE_SMOOTH));  // Ajuste o tamanho da imagem
        JLabel imgLabel = new JLabel(img);
        imgLabel.setHorizontalAlignment(JLabel.CENTER); // Centralizar a imagem
        mainPanel.add(imgLabel, BorderLayout.CENTER); // Adicionar a imagem ao centro do painel
    
        btn = new JButton("Start");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcao();
            }
        });
        btn.setHorizontalAlignment(JButton.CENTER); // Centralizar o botão
        mainPanel.add(btn, BorderLayout.SOUTH); // Adicionar o botão ao fundo do painel
    
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private void opcao() {
        mainPanel.removeAll();

        mainPanel.setLayout(new BorderLayout()); // Layout

        label = new JLabel("<html><h2>Selecione a ação desejada:</h2>");
        label.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(label, BorderLayout.NORTH);

        JPanel comboBoxPanel = new JPanel();
        comboBoxPanel.setLayout(new FlowLayout()); // layout dif do main
    
        String[] opcoes = {"Cadastrar eventos", "Mostrar eventos", "Relatorio de receitas", "Encerrar o sistema"};
        comboBox = new JComboBox<>(opcoes);
        comboBox.setPreferredSize(new Dimension(200, 30)); 

        comboBoxPanel.add(comboBox); //div
        mainPanel.add(comboBoxPanel, BorderLayout.CENTER);

        btn = new JButton("GO");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch ((String) comboBox.getSelectedItem()) {
                    case "Cadastrar eventos":
                        cadastroEvento();
                        break;
                    case "Mostrar eventos":
                        exibeEventos();
                        break;
                    case "Relatorio de receitas":
                        //exibeExtrato();
                        break;
                    case "Encerrar o sistema":
                        System.exit(0);
                        break;
                }
            }
        });
        mainPanel.add(btn, BorderLayout.SOUTH);

        frame.revalidate();
        frame.repaint();
    }

    private void cadastroEvento() {
        mainPanel.removeAll();

        JPanel cadastroPanel = new JPanel();
        cadastroPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel tipoLabel = new JLabel("Tipo:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        cadastroPanel.add(tipoLabel, gbc);

        JComboBox<String> tipoComboBox = new JComboBox<>(new String[]{"Peça", "Filme", "Concerto"});
        gbc.gridx = 1;
        gbc.gridy = 0;
        cadastroPanel.add(tipoComboBox, gbc);

        JLabel nameLabel = new JLabel("Nome:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        cadastroPanel.add(nameLabel, gbc);

        JTextField nameField = new JTextField(30);
        gbc.gridx = 1;
        gbc.gridy = 1;
        cadastroPanel.add(nameField, gbc);

        JLabel dataLabel = new JLabel("Data:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        cadastroPanel.add(dataLabel, gbc);

        JTextField dataField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 2;
        cadastroPanel.add(dataField, gbc);

        JLabel localLabel = new JLabel("Local:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        cadastroPanel.add(localLabel, gbc);

        JTextField localField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        cadastroPanel.add(localField, gbc);

        JLabel precoLabel = new JLabel("Preço:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        cadastroPanel.add(precoLabel, gbc);

        JTextField precoField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 4;
        cadastroPanel.add(precoField, gbc);

        btn = new JButton("Cadastrar");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipo = (String) tipoComboBox.getSelectedItem();
                String nome = nameField.getText();
                String data = dataField.getText();
                String local = localField.getText();
                Double preco = Double.parseDouble(precoField.getText());
                
                Evento  newEv = null;
                switch (tipo) {
                    case "Peça":
                        newEv = (new Teatro(nome, data, local, preco));
                        break;
                    case "Filme":
                        newEv = (new Filme(nome, data, local, preco));
                        break;
                    case "Concerto":
                        newEv = (new Concerto(nome, data, local, preco));
                        break;
                }

                if (!Sistema.eventos.contains(newEv))Sistema.eventos.add(newEv);

                opcao();
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 5;
        cadastroPanel.add(btn, gbc);

        JButton btnS = new JButton("Sair");
        btnS.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcao();
            }
        });

        gbc.gridx = 2;
        gbc.gridy = 5;
        cadastroPanel.add(btnS, gbc);

        mainPanel.add(cadastroPanel, BorderLayout.WEST);

        frame.revalidate();
        frame.repaint();
    }

    private void exibeEventos() {
        mainPanel.removeAll();
    
        // Exibir os eventos cadastrados
        label = new JLabel("<html><h2>Selecione o evento desejado:</h2></html>");
        label.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(label, BorderLayout.NORTH);
    
        JPanel eventosPanel = new JPanel();
        eventosPanel.setLayout(new BoxLayout(eventosPanel, BoxLayout.Y_AXIS));

       // Crie um modelo de tabela
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Tipo"); // Adicione as colunas que você precisa
        tableModel.addColumn("Nome");
        tableModel.addColumn("Data");
        tableModel.addColumn("Local");
        tableModel.addColumn("Preço Ingresso");
        tableModel.addColumn("Receita evento");
        tableModel.addColumn("Ingressos disponíveis");
        tableModel.addColumn("Ingressos vendidos");

        // Adicione os eventos à tabela
        tableModel.setRowCount(0);
        for (Evento evento : Sistema.eventos) {
            Object[] row = evento.toArray(); // Supondo que você tenha um método toArray() em Evento
            tableModel.addRow(row);
        }

        // Crie a tabela
        JTable table = new JTable(tableModel);
        table.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        eventosPanel.add(new JScrollPane(table));

        // Centralize as células
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < 8; i++)  table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);

        // Adicione a tabela ao painel
        eventosPanel.add(new JScrollPane(table));
        // Para tornar as linhas da tabela selecionáveis, você pode usar o método setRowSelectionAllowed()
        table.setRowSelectionAllowed(true);

        // Botão para continuar
        JButton btnCompra = new JButton("Comprar Ingressos");
        JButton btnExtrato = new JButton("Mais detalhes");

        // Para obter o evento selecionado, você pode usar o método getSelectedRow()
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    Evento eventoSelecionado = Sistema.eventos.get(selectedRow);
                    btnCompra.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (selectedRow != -1) {
                                // get ev selected
                                selecionarTipoIngresso(eventoSelecionado);
                            } else {
                                JOptionPane.showMessageDialog(frame, "Por favor, selecione um evento antes de continuar.");
                            }
                        }
                    });
                
                    btnExtrato.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (selectedRow != -1) {
                                exibeExtrato(eventoSelecionado);
                            } else {
                                JOptionPane.showMessageDialog(frame, "Por favor, selecione um evento antes de continuar.");
                            }
                        }
                    });
                }
            }
        });
        

        JLabel rt = new JLabel("\nReceita Total: " + Sistema.calculaReceitaTotal());
        eventosPanel.add(rt);
    
        mainPanel.add(eventosPanel, BorderLayout.CENTER);



        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout());
        buttonsPanel.add(btnCompra);
        buttonsPanel.add(btnExtrato);
    
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);
    
        frame.revalidate();
        frame.repaint();
    }
    
    private void selecionarTipoIngresso(Evento evento) {
        mainPanel.removeAll();
    
        // Exibir os tipos de ingresso
        label = new JLabel("<html><h2>Selecione o tipo de ingresso:</h2></html>");
        label.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(label, BorderLayout.NORTH);
    
        JPanel tiposPanel = new JPanel();
        tiposPanel.setLayout(new BoxLayout(tiposPanel, BoxLayout.Y_AXIS));
        
        ButtonGroup tiposGroup = new ButtonGroup();
        JRadioButton vipButton = new JRadioButton("VIP");
        JRadioButton meiaButton = new JRadioButton("Meia");
        JRadioButton padraoButton = new JRadioButton("Padrão");

        vipButton.setActionCommand("VIP");
        meiaButton.setActionCommand("Meia");
        padraoButton.setActionCommand("Normal");

        tiposGroup.add(vipButton);
        tiposGroup.add(meiaButton);
        tiposGroup.add(padraoButton);

        
        if (!evento.getClass().equals(Filme.class)) tiposPanel.add(vipButton);
        tiposPanel.add(meiaButton);
        tiposPanel.add(padraoButton);
    
        mainPanel.add(tiposPanel, BorderLayout.CENTER);
    
        // Botão para confirmar a compra
        btn = new JButton("Confirmar Compra");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedTipoIngresso = tiposGroup.getSelection().getActionCommand();
                System.out.println(selectedTipoIngresso);
                confirmarCompra(evento, selectedTipoIngresso);
            }
        });
        mainPanel.add(btn, BorderLayout.SOUTH);
    
        frame.revalidate();
        frame.repaint();
    }
    
    private void confirmarCompra(Evento evento, String tipoIngresso) {
        mainPanel.removeAll();
        
        Ingresso i = null;
        switch (tipoIngresso) {
            case "VIP":
                i = new Vip(new Date(), evento.getPreco());
                break;
            
            case "Meia":
                i = new Meia(new Date(), evento.getPreco());
                break;
            
            case "Normal":
                i = new Normal(new Date(), evento.getPreco());
                break;

            default:
                break;
        }

        String l = "", b = "";
        if (evento.novoIngresso(i)){
            l = "<html><h2>Compra confirmada!</h2></html>";
            b = "Voltar ao Menu Principal";
        }else {
            l = "<html><h2>Ingresso não disponível!</h2></html>";
            b = "Tentar Novamente";
            selecionarTipoIngresso(evento);
        }
            
        // Mensagem de confirmação
        label = new JLabel(l);
        label.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(label, BorderLayout.CENTER);
    
        JLabel detalhesLabel = new JLabel("<html><h3>Evento: " + evento.getNome() + "<br>Tipo de Ingresso: " + tipoIngresso + "</h3></html>");
        detalhesLabel.setHorizontalAlignment(JLabel.CENTER); // Centralizar o label
        mainPanel.add(detalhesLabel, BorderLayout.CENTER);
    
        // Botão para voltar ao menu principal
        btn = new JButton(b);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcao();
            }
        });
        mainPanel.add(btn, BorderLayout.SOUTH);
    
        frame.revalidate();
        frame.repaint();
    }

    void exibeExtrato(Evento e){
        mainPanel.removeAll();

        label = new JLabel(e.exibeExtrato());
        mainPanel.add(label);

        JButton btnS = new JButton("Sair");
        btnS.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcao();
            }
        });

        mainPanel.add(btnS, BorderLayout.SOUTH);

        frame.revalidate();
        frame.repaint();
    }
    
}