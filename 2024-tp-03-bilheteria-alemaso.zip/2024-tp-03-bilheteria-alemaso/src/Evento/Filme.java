package Evento;

import Ingresso.Ingresso;

public class Filme extends Evento{

    public Filme(String nome, String data, String local, double preco) {
        super(nome, data, local, preco);
        this.qtdIngressos = 200;
    }

    public boolean ingressoDisponivel(){
        return (ingressosVendidos.size() < qtdIngressos); // NO VIP
    }

    @Override
    public String toString() {
       return
        "Filme: " + nome + "   " +
        "Data: " + data + "   " +
        "Local: " + local + "   " +
        "Preço do ingresso: R$" + preco + "     " +
        "Receita toal: R$" + calculaReceita() +
        "Ingressos disponíveis: " + (qtdIngressos - ingressosVendidos.size()) + "   " +
        "Ingressos vendidos: " + ingressosVendidos.size();
    }


    @Override
    public String exibeExtrato() {
        String s = "Filme " + nome + ", ";
        for (Ingresso i : ingressosVendidos) {
            s += "\n" +  i.exibeExtrato() + ", ";
        }
        s += "Receita total gerada: R$" + calculaReceita() + "\n";
        return s;
    }
    
    public Object[] toArray(){
        return new Object[]{"Filme", nome, data, local, preco, calculaReceita(), (qtdIngressos - ingressosVendidos.size()), ingressosVendidos.size()};
    }

}
