package Evento;

import Ingresso.*;

public class Teatro extends Evento{

    public Teatro(String nome, String data, String local, double preco) {
        super(nome, data, local, preco);
        this.qtdIngressos = 250;
    }
    
    public boolean ingressoDisponivel(){
        return (ingressosVendidos.size() < qtdIngressos && ingressosVendidos.stream().filter(Meia.class::isInstance).count() < qtdIngressos*0.2);
    }

    @Override
    public String toString() {
       return
        "TEATRO: " + nome + "   " +
        "DATA: " + data + "   " +
        "LOCAL: " + local + "   " +
        "INGRESSO: R$" + preco + "   " +
        "Receita total: R$" + calculaReceita() +
        "Ingressos disponíveis: " + (qtdIngressos - ingressosVendidos.size()) + "   " +
        "Ingressos vendidos: " + ingressosVendidos.size();
    }


    @Override
    public String exibeExtrato() {
        String s = "Teatro " + nome + ", ";
        for (Ingresso i : ingressosVendidos) {
            s += "\n" +  i.exibeExtrato() + ", ";
        }
        s += "Receita total gerada: R$" + calculaReceita() + "\n";
        return s;
    }

    public Object[] toArray(){
        return new Object[]{"Teatro", nome, data, local, preco, calculaReceita(), (qtdIngressos - ingressosVendidos.size()), ingressosVendidos.size()};
    }

}
