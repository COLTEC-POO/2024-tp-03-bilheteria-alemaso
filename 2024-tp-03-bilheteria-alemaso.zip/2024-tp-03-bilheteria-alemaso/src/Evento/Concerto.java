package Evento;

import Ingresso.*;

public class Concerto extends Evento{

    public Concerto(String nome, String data, String local, double preco) {
        super(nome, data, local, preco);
        this.qtdIngressos = 150;
    }

    @Override
    public boolean ingressoDisponivel(){
        return (ingressosVendidos.size() < qtdIngressos && ingressosVendidos.stream().filter(Vip.class::isInstance).count() < qtdIngressos*0.1);
    }

    @Override
    public String toString() {
       return
        "Concerto: " + nome + "   " +
        "Data: " + data + "   " +
        "Local: " + local + "   " +
        "Preço do ingresso: R$" + preco + "     " +
        "Receita toal: R$" + calculaReceita() +
        "Ingressos disponíveis: " + (qtdIngressos - ingressosVendidos.size()) + "   " +
        "Ingressos vendidos: " + ingressosVendidos.size();
    }


    @Override
    public String exibeExtrato() {
        String s = "Cncerto " + nome + ", ";
        for (Ingresso i : ingressosVendidos) {
            s += "\n" +  i.exibeExtrato() + ", ";
        }
        s += "Receita total gerada: R$" + calculaReceita() + "\n";
        return s;
    }

    public Object[] toArray(){
        return new Object[]{"Concerto", nome, data, local, preco, calculaReceita(), (qtdIngressos - ingressosVendidos.size()), ingressosVendidos.size()};
    }
    
}
