package Evento;

import Sistema.*;
import java.time.*;
import Receita.Receita;
import java.util.ArrayList;

import Ingresso.Ingresso;

public abstract class Evento implements Receita{
    protected String nome;
    protected String data; //LocalDate.of() //data, hora
    protected String dataVenda;
    protected String local;
    protected double preco;
    protected int qtdIngressos;
    protected ArrayList<Ingresso> ingressosVendidos;



    public Evento(String nome, String data, String local, double preco) { 
        this.nome = nome;
        Sistema.eventos.add(this);
        this.data = data; // [DD,MM,AA,hh,mm]
        this.local = local; 
        this.preco = preco;
        this.ingressosVendidos = new ArrayList<Ingresso>();
    }

    public String getNome() {
        return nome;
    }

    public String getData() {
        return data;
    }
    public String getLocal() {
        return local;
    }
    public double getPreco() {
        return preco;
    }
    public ArrayList<Ingresso> getIngressosVendidos() {
        return ingressosVendidos;
    }

    public boolean novoIngresso(Ingresso i){
        if (ingressoDisponivel()){
            ingressosVendidos.add(i);

            return true;
        }
        else return false;
    }

    protected abstract boolean ingressoDisponivel();

    @Override
    public double calculaReceita() {
        double total = 0;
        for (Ingresso i : ingressosVendidos){
            total += i.calculaReceita();
        }
        return total;
    }

    public abstract Object[] toArray();

}
