package Receita;

public interface Receita {
    double calculaReceita();
    String exibeExtrato();
}
