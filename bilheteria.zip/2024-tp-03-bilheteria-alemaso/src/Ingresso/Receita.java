package Ingresso;

public interface Receita {
    double calculaReceita();
    String exibeExtrato();
}
