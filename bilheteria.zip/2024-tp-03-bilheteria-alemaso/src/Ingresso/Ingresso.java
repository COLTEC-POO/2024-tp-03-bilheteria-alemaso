package Ingresso;

import java.util.*;

public abstract class Ingresso implements Receita{
    protected Date dataVenda;
    protected double valor;

    public Ingresso(Date data) {
        this.dataVenda = data;
        this.valor = valor;
    }
}
